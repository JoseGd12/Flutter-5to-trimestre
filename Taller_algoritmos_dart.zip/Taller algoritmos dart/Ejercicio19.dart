import 'dart:io';

void main() {
  print('=== SISTEMA ACADÉMICO ESTUDIANTE ===');
  
  stdout.write('Ingrese el nombre del estudiante: ');
  String nombre = stdin.readLineSync()!;
  
  stdout.write('Ingrese el programa de formación: ');
  String programa = stdin.readLineSync()!;
  
  stdout.write('Ingrese la ficha: ');
  String ficha = stdin.readLineSync()!;
  
  double sumaNotas = 0;
  for (int i = 1; i <= 5; i++) {
    stdout.write('Ingrese la nota $i: ');
    double nota = double.parse(stdin.readLineSync()!);
    sumaNotas += nota;
  }
  
  double promedio = sumaNotas / 5;
  
  print('\n--- INFORMACIÓN ACADÉMICA ---');
  print('Nombre: $nombre');
  print('Programa: $programa');
  print('Ficha: $ficha');
  print('Promedio final: ${promedio.toStringAsFixed(2)}');
}