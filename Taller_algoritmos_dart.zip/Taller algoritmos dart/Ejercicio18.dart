import 'dart:io';

void main() {
  print('=== CALCULO DE CUOTAS DE MATRÍCULA ===');
  
  stdout.write('Ingrese el valor total de la matrícula: ');
  double matricula = double.parse(stdin.readLineSync()!);
  
  double cuota1 = matricula * 0.40;
  double cuota2 = matricula * 0.25;
  double cuota3 = matricula * 0.20;
  double cuota4 = matricula * 0.15;
  
  print('\nPlan de pagos:');
  print('Valor matrícula: \$${matricula.toStringAsFixed(2)}');
  print('Primera cuota (40%): \$${cuota1.toStringAsFixed(2)}');
  print('Segunda cuota (25%): \$${cuota2.toStringAsFixed(2)}');
  print('Tercera cuota (20%): \$${cuota3.toStringAsFixed(2)}');
  print('Cuarta cuota (15%): \$${cuota4.toStringAsFixed(2)}');
}