import 'dart:io';

void main() {
  print('=== CALCULO DE SUELDO CON COMISIONES ===');
  
  stdout.write('Ingrese el sueldo base: ');
  double sueldoBase = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el valor de la primera venta: ');
  double venta1 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el valor de la segunda venta: ');
  double venta2 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el valor de la tercera venta: ');
  double venta3 = double.parse(stdin.readLineSync()!);
  
  double totalVentas = venta1 + venta2 + venta3;
  double comisiones = totalVentas * 0.10;
  double totalMes = sueldoBase + comisiones;
  
  print('\nDesglose de pago:');
  print('Sueldo base: \$${sueldoBase.toStringAsFixed(2)}');
  print('Total ventas: \$${totalVentas.toStringAsFixed(2)}');
  print('Comisiones (10%): \$${comisiones.toStringAsFixed(2)}');
  print('TOTAL A RECIBIR: \$${totalMes.toStringAsFixed(2)}');
}