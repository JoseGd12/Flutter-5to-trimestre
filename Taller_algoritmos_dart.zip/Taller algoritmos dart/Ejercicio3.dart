import 'dart:io';

void main() {
  print('=== CALCULO DE NOTA DEFINITIVA ===');
  
  stdout.write('Ingrese la primera nota: ');
  double nota1 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la segunda nota: ');
  double nota2 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la tercera nota: ');
  double nota3 = double.parse(stdin.readLineSync()!);
  
  double definitiva = (nota1 + nota2 + nota3) / 3;
  
  print('\nResultado:');
  print('Nota 1: $nota1');
  print('Nota 2: $nota2');
  print('Nota 3: $nota3');
  print('Definitiva: ${definitiva.toStringAsFixed(2)}');
}