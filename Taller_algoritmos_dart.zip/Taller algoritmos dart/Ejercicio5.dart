import 'dart:io';

void main() {
  print('=== CALCULO DE VELOCIDAD ===');
  
  stdout.write('Ingrese la distancia recorrida (km): ');
  double distancia = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el tiempo empleado (horas): ');
  double tiempo = double.parse(stdin.readLineSync()!);
  
  double velocidad = distancia / tiempo;
  
  print('\nResultado:');
  print('Distancia: $distancia km');
  print('Tiempo: $tiempo horas');
  print('Velocidad: ${velocidad.toStringAsFixed(2)} km/h');
}