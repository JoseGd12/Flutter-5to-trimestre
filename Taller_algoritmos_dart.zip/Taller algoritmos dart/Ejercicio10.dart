import 'dart:io';

void main() {
  print('=== CALCULO DE DESCUENTO DEL 15% ===');
  
  stdout.write('Ingrese el total de la compra: ');
  double compra = double.parse(stdin.readLineSync()!);
  
  double descuento = compra * 0.15;
  double totalPagar = compra - descuento;
  
  print('\nResultado:');
  print('Total compra: \$${compra.toStringAsFixed(2)}');
  print('Descuento (15%): \$${descuento.toStringAsFixed(2)}');
  print('Total a pagar: \$${totalPagar.toStringAsFixed(2)}');
}