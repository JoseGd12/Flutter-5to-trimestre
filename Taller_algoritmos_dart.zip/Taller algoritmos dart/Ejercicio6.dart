import 'dart:io';

void main() {
  print('=== CALCULO DE FACTURA CON DESCUENTO E IVA ===');
  
  stdout.write('Ingrese el valor de la compra: ');
  double compra = double.parse(stdin.readLineSync()!);
  
  double descuento = compra * 0.10;
  double compraConDescuento = compra - descuento;
  double iva = compraConDescuento * 0.19;
  double total = compraConDescuento + iva;
  
  print('\nDesglose de la factura:');
  print('Valor compra: \$${compra.toStringAsFixed(2)}');
  print('Descuento (10%): \$${descuento.toStringAsFixed(2)}');
  print('Subtotal: \$${compraConDescuento.toStringAsFixed(2)}');
  print('IVA (19%): \$${iva.toStringAsFixed(2)}');
  print('TOTAL A PAGAR: \$${total.toStringAsFixed(2)}');
}