void main() {
  print('=== TIEMPO DE LLENADO DE BALDES ===');
  
  // Balde de 1 litro tarda 1.5 horas (90 minutos)
  double tiempoBase = 1.5; // horas para 1 litro
  
  // Tiempo proporcional al volumen
  double tiempo5Litros = 5 * tiempoBase;
  double tiempo3Litros = 3 * tiempoBase;
  
  print('Balde de 1 litro: ${tiempoBase.toStringAsFixed(2)} horas');
  print('Balde de 3 litros: ${tiempo3Litros.toStringAsFixed(2)} horas');
  print('Balde de 5 litros: ${tiempo5Litros.toStringAsFixed(2)} horas');
  
  // Para baldes de tamaño desconocido
  print('\n--- PARA BALDES DESCONOCIDOS ---');
  print('Fórmula: Tiempo = Capacidad × 1.5 horas');
  print('Donde 1.5 horas es el tiempo para 1 litro');
}