import 'dart:io';

void main() {
  print('=== TIEMPO PARA ESCALAR ===');
  
  // Base: 5 horas para 7 metros
  double tiempoBase = 5.0; // horas
  double alturaBase = 7.0; // metros
  
  stdout.write('Ingrese la altura que desea escalar (metros): ');
  double alturaDeseada = double.parse(stdin.readLineSync()!);
  
  // Regla de tres simple
  double tiempoRequerido = (alturaDeseada * tiempoBase) / alturaBase;
  
  print('\nResultado:');
  print('Tiempo base: $tiempoBase horas para $alturaBase metros');
  print('Altura deseada: $alturaDeseada metros');
  print('Tiempo estimado: ${tiempoRequerido.toStringAsFixed(2)} horas');
}