import 'dart:io';

void main() {
  print('=== DATOS PERSONALES Y EDAD ===');
  
  stdout.write('Ingrese el nombre: ');
  String nombre = stdin.readLineSync()!;
  
  stdout.write('Ingrese la dirección: ');
  String direccion = stdin.readLineSync()!;
  
  stdout.write('Ingrese el año de nacimiento: ');
  int añoNacimiento = int.parse(stdin.readLineSync()!);
  
  DateTime ahora = DateTime.now();
  int edad = ahora.year - añoNacimiento;
  
  print('\n--- INFORMACIÓN COMPLETA ---');
  print('Nombre: $nombre');
  print('Dirección: $direccion');
  print('Año de nacimiento: $añoNacimiento');
  print('Edad: $edad años');
}