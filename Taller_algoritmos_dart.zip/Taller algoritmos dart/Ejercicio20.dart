import 'dart:io';

void main() {
  print('=== CALCULO DE COMPRA CON IVA ===');
  
  stdout.write('Ingrese el precio unitario del producto: ');
  double precio = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la cantidad: ');
  int cantidad = int.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el porcentaje de descuento (%): ');
  double descuentoPorcentaje = double.parse(stdin.readLineSync()!);
  
  double subtotal = precio * cantidad;
  double descuento = subtotal * (descuentoPorcentaje / 100);
  double subtotalConDescuento = subtotal - descuento;
  double iva = subtotalConDescuento * 0.19;
  double neto = subtotalConDescuento + iva;
  
  print('\n--- DETALLE DE COMPRA ---');
  print('Subtotal: \$${subtotal.toStringAsFixed(2)}');
  print('Descuento (${descuentoPorcentaje}%): \$${descuento.toStringAsFixed(2)}');
  print('Subtotal con descuento: \$${subtotalConDescuento.toStringAsFixed(2)}');
  print('IVA (19%): \$${iva.toStringAsFixed(2)}');
  print('PRECIO NETO: \$${neto.toStringAsFixed(2)}');
}