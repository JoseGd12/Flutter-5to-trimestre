import 'dart:io';

void main() {
  print('=== FACTURA DE COMPRA (4 ARTÍCULOS) ===');
  
  double subtotal = 0;
  
  for (int i = 1; i <= 4; i++) {
    print('\nArtículo $i:');
    stdout.write('Precio unitario: ');
    double precio = double.parse(stdin.readLineSync()!);
    
    stdout.write('Cantidad: ');
    int cantidad = int.parse(stdin.readLineSync()!);
    
    subtotal += precio * cantidad;
  }
  
  double iva = subtotal * 0.19;
  double total = subtotal + iva;
  
  print('\n--- FACTURA ---');
  print('Subtotal: \$${subtotal.toStringAsFixed(2)}');
  print('IVA (19%): \$${iva.toStringAsFixed(2)}');
  print('TOTAL: \$${total.toStringAsFixed(2)}');
}