import 'dart:io';

void main() {
  print('=== COLILLA DE PAGO ===');
  
  stdout.write('Ingrese el salario del empleado: ');
  double salario = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el valor de ahorro mensual programado: ');
  double ahorro = double.parse(stdin.readLineSync()!);
  
  double eps = salario * 0.125;
  double pension = salario * 0.16;
  double totalDeducciones = eps + pension + ahorro;
  double totalRecibir = salario - totalDeducciones;
  
  print('\n--- COLILLA DE PAGO ---');
  print('Salario: \$${salario.toStringAsFixed(2)}');
  print('Ahorro programado: \$${ahorro.toStringAsFixed(2)}');
  print('Deducción EPS (12.5%): \$${eps.toStringAsFixed(2)}');
  print('Deducción Pensión (16%): \$${pension.toStringAsFixed(2)}');
  print('Total deducciones: \$${totalDeducciones.toStringAsFixed(2)}');
  print('TOTAL A RECIBIR: \$${totalRecibir.toStringAsFixed(2)}');
}