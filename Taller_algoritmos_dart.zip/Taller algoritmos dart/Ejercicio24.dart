import 'dart:io';

void main() {
  print('=== CALCULO DE PRÉSTAMO ===');
  
  stdout.write('Ingrese el monto del préstamo: ');
  double monto = double.parse(stdin.readLineSync()!);
  
  double tasaAnual = 0.05; // 5% anual
  double tasaMensual = tasaAnual / 12;
  double tasaTrimestral = tasaAnual / 4;
  
  // Cálculos
  double interesesAnual = monto * tasaAnual;
  double interesesTrimestre = monto * tasaTrimestral;
  double interesesMes = monto * tasaMensual;
  double totalPagar = monto + (interesesAnual * 5); // 5 años
  
  print('\n--- DETALLE DEL PRÉSTAMO ---');
  print('Monto del préstamo: \$${monto.toStringAsFixed(2)}');
  print('Tasa de interés: ${(tasaAnual * 100).toStringAsFixed(2)}% anual');
  print('\nIntereses pagados:');
  print('• En un año: \$${interesesAnual.toStringAsFixed(2)}');
  print('• En el tercer trimestre: \$${interesesTrimestre.toStringAsFixed(2)}');
  print('• En el primer mes: \$${interesesMes.toStringAsFixed(2)}');
  print('\nTotal a pagar en 5 años: \$${totalPagar.toStringAsFixed(2)}');
}