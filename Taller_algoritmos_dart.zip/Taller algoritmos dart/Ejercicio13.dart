import 'dart:io';

void main() {
  print('=== CALCULO DE SALARIO ===');
  
  stdout.write('Ingrese las horas trabajadas: ');
  double horas = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el valor por hora: ');
  double valorHora = double.parse(stdin.readLineSync()!);
  
  double salario = horas * valorHora;
  
  print('\nResultado:');
  print('Horas trabajadas: $horas');
  print('Valor por hora: \$${valorHora.toStringAsFixed(2)}');
  print('SALARIO: \$${salario.toStringAsFixed(2)}');
}