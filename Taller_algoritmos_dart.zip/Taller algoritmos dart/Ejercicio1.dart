import 'dart:io';

void main() {
  print('=== SUMA DE TRES NÚMEROS ===');
  
  stdout.write('Ingrese el primer número: ');
  double num1 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el segundo número: ');
  double num2 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el tercer número: ');
  double num3 = double.parse(stdin.readLineSync()!);
  
  double suma = num1 + num2 + num3;
  
  print('\nResultado:');
  print('$num1 + $num2 + $num3 = $suma');
}