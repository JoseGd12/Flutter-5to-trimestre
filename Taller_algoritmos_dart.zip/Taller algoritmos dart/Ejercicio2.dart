import 'dart:io';

void main() {
  print('=== OPERACIONES CON DOS NÚMEROS ===');
  
  stdout.write('Ingrese el primer número: ');
  double num1 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese el segundo número: ');
  double num2 = double.parse(stdin.readLineSync()!);
  
  double suma = num1 + num2;
  double resta = num1 - num2;
  double multiplicacion = num1 * num2;
  double division = num1 / num2;
  
  print('\nResultados:');
  print('$num1 + $num2 = $suma');
  print('$num1 - $num2 = $resta');
  print('$num1 * $num2 = $multiplicacion');
  print('$num1 / $num2 = $division');
}