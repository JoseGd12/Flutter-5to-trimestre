import 'dart:io';

void main() {
  print('=== SISTEMA DE VENTAS ===');
  
  stdout.write('Ingrese el monto de la venta: ');
  double venta = double.parse(stdin.readLineSync()!);
  
  double iva = venta * 0.19;
  double total = venta + iva;
  
  print('\n--- DETALLE DE VENTA ---');
  print('Monto venta: \$${venta.toStringAsFixed(2)}');
  print('IVA (19%): \$${iva.toStringAsFixed(2)}');
  print('TOTAL A PAGAR: \$${total.toStringAsFixed(2)}');
  
  stdout.write('\nIngrese la cantidad con la que paga el cliente: ');
  double pago = double.parse(stdin.readLineSync()!);
  
  double cambio = pago - total;
  
  print('Pago recibido: \$${pago.toStringAsFixed(2)}');
  print('CAMBIO: \$${cambio.toStringAsFixed(2)}');
}