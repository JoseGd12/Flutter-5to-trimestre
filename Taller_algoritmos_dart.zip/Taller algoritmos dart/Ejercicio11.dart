import 'dart:io';

void main() {
  print('=== CALCULO DE CALIFICACIÓN FINAL ===');
  
  print('Ingrese las tres calificaciones parciales:');
  stdout.write('Parcial 1: ');
  double p1 = double.parse(stdin.readLineSync()!);
  stdout.write('Parcial 2: ');
  double p2 = double.parse(stdin.readLineSync()!);
  stdout.write('Parcial 3: ');
  double p3 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la calificación del examen final: ');
  double examen = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la calificación del trabajo final: ');
  double trabajo = double.parse(stdin.readLineSync()!);
  
  double promedioParciales = (p1 + p2 + p3) / 3;
  double notaFinal = (promedioParciales * 0.55) + (examen * 0.30) + (trabajo * 0.15);
  
  print('\nResultado:');
  print('Promedio parciales (55%): ${promedioParciales.toStringAsFixed(2)}');
  print('Examen final (30%): $examen');
  print('Trabajo final (15%): $trabajo');
  print('CALIFICACIÓN FINAL: ${notaFinal.toStringAsFixed(2)}');
}