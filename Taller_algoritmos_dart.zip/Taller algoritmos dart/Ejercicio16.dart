import 'dart:io';

void main() {
  print('=== CALCULO DE PAGO CONDUCTOR ===');
  
  stdout.write('Ingrese el total recaudado en el día: ');
  double recaudado = double.parse(stdin.readLineSync()!);
  
  double pagoConductor = recaudado * 0.19;
  
  print('\nResultado:');
  print('Total recaudado: \$${recaudado.toStringAsFixed(2)}');
  print('Pago conductor (19%): \$${pagoConductor.toStringAsFixed(2)}');
}