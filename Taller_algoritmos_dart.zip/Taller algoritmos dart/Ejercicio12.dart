import 'dart:io';

void main() {
  print('=== PORCENTAJE DE HOMBRES Y MUJERES ===');
  
  stdout.write('Ingrese la cantidad de hombres: ');
  int hombres = int.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la cantidad de mujeres: ');
  int mujeres = int.parse(stdin.readLineSync()!);
  
  int total = hombres + mujeres;
  double porcentajeHombres = (hombres / total) * 100;
  double porcentajeMujeres = (mujeres / total) * 100;
  
  print('\nResultado:');
  print('Total estudiantes: $total');
  print('Hombres: $hombres (${porcentajeHombres.toStringAsFixed(2)}%)');
  print('Mujeres: $mujeres (${porcentajeMujeres.toStringAsFixed(2)}%)');
}