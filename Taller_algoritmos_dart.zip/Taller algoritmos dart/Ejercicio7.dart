import 'dart:io';

void main() {
  print('=== CONVERSIÓN DE TIEMPO A SEGUNDOS ===');
  
  stdout.write('Ingrese las horas: ');
  int horas = int.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese los minutos: ');
  int minutos = int.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese los segundos: ');
  int segundos = int.parse(stdin.readLineSync()!);
  
  int totalSegundos = (horas * 3600) + (minutos * 60) + segundos;
  
  print('\nResultado:');
  print('$horas h, $minutos min, $segundos seg');
  print('Equivale a: $totalSegundos segundos');
}