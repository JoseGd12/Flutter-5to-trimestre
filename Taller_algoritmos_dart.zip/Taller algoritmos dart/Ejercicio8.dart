import 'dart:io';

void main() {
  print('=== CALCULO DE INVERSIÓN ===');
  
  stdout.write('Ingrese el capital a invertir: ');
  double capital = double.parse(stdin.readLineSync()!);
  
  double interesMensual = capital * 0.02;
  double totalMes = capital + interesMensual;
  
  print('\nResultado después de un mes:');
  print('Capital inicial: \$${capital.toStringAsFixed(2)}');
  print('Interés ganado (2%): \$${interesMensual.toStringAsFixed(2)}');
  print('Total: \$${totalMes.toStringAsFixed(2)}');
}