import 'dart:io';

void main() {
  print('=== CALCULO DE NOTA DEFINITIVA CON PORCENTAJES ===');
  
  stdout.write('Ingrese la primera nota (20%): ');
  double nota1 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la segunda nota (30%): ');
  double nota2 = double.parse(stdin.readLineSync()!);
  
  stdout.write('Ingrese la tercera nota (50%): ');
  double nota3 = double.parse(stdin.readLineSync()!);
  
  double definitiva = (nota1 * 0.20) + (nota2 * 0.30) + (nota3 * 0.50);
  
  print('\nResultado:');
  print('Nota 1 (20%): $nota1 → ${nota1 * 0.20}');
  print('Nota 2 (30%): $nota2 → ${nota2 * 0.30}');
  print('Nota 3 (50%): $nota3 → ${nota3 * 0.50}');
  print('Definitiva: ${definitiva.toStringAsFixed(2)}');
}